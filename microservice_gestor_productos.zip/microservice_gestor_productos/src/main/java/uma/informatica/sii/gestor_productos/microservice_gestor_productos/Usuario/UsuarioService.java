package uma.informatica.sii.gestor_productos.microservice_gestor_productos.Usuario;

import java.util.Arrays;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.RequestEntity;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.util.UriComponentsBuilder;

import uma.informatica.sii.gestor_productos.microservice_gestor_productos.security.JwtUtil;

@Service
public class UsuarioService {

    @Value("${servicio.usuarios.baseurl}")
    private String baseUrl;

    private final Usuario usuarioAplicacion;
    private final JwtUtil jwtUtil;
    private final RestTemplate restTemplate;

    public UsuarioService(RestTemplate restTemplate, JwtUtil jwtUtil) {
        this.restTemplate = restTemplate;
        this.jwtUtil = jwtUtil;
        this.usuarioAplicacion = Usuario.builder()
            .id(-1L)
            .role(Usuario.Rol.ADMINISTRADOR)
            .nombre("Servicio de llamadas")
            .build();
    }

    public Optional<UsuarioDTO> getUsuarioConectado(String jwtToken) {
        // ✅ TEMPORARY MOCK: bypass external service
        if (jwtToken != null && jwtToken.startsWith("Bearer")) {
            UsuarioDTO mock = new UsuarioDTO();
            mock.setId(1L);             // match the userId in your JWT
            mock.setCuentaId(1);        // must match categoria.cuentaId
            mock.setNombre("Admin Local");
            mock.setRole(Usuario.Rol.ADMINISTRADOR);
            return Optional.of(mock);
        }
    
        // 🔒 Original logic (kept for production)
        var peticion = RequestEntity.get(baseUrl + "/usuario")
            .header("Authorization", jwtToken)
            .build();
    
        try {
            return Optional.of(restTemplate.exchange(peticion, UsuarioDTO[].class).getBody()[0]);
        } catch (Exception e) {
            return Optional.empty();
        }
    }
    public Integer getCuentaIdDelUsuario(Long usuarioId, String jwtToken) {
        String tokenFinal = jwtToken.startsWith("Bearer ") ? jwtToken : "Bearer " + jwtToken;

        var peticion = RequestEntity.get(baseUrl + "/usuario")
            .header("Authorization", tokenFinal)
            .build();

        try {
            UsuarioDTO[] body = restTemplate.exchange(peticion, UsuarioDTO[].class).getBody();
            if (body != null && body.length > 0) {
                return body[0].getCuentaId();
            } else {
                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Cuenta no encontrada");
            }
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Cuenta no encontrada", e);
        }
    }

    public boolean usuarioPerteneceACuenta(Integer idCuenta, Long idUsuario, String jwtTokenDelUsuario) {
        String url = baseUrl + "/cuenta/" + idCuenta + "/usuarios";
        String tokenServicio = jwtUtil.generateToken(usuarioAplicacion);

        var peticion = RequestEntity.get(url)
            .header("Authorization", "Bearer " + tokenServicio)
            .build();

        try {
            var respuesta = restTemplate.exchange(peticion, UsuarioDTO[].class).getBody();
            return Arrays.stream(respuesta).anyMatch(u -> u.getId().equals(idUsuario));
        } catch (Exception e) {
            return false;
        }
    }

    private Optional<UsuarioDTO> getUsuarioPorId(Long id, String jwtToken) {
        String tokenFinal = jwtToken.startsWith("Bearer ") ? jwtToken : "Bearer " + jwtToken;

        var peticion = RequestEntity.get(baseUrl + "/usuario")
            .header("Authorization", tokenFinal)
            .build();

        try {
            UsuarioDTO[] body = restTemplate.exchange(peticion, UsuarioDTO[].class).getBody();
            if (body != null && body.length > 0) {
                return Optional.of(body[0]);
            } else {
                return Optional.empty();
            }
        } catch (Exception e) {
            return Optional.empty();
        }
    }
}