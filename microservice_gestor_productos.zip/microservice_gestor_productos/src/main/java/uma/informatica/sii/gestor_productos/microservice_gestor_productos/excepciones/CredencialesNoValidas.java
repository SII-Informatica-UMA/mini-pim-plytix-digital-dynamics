package uma.informatica.sii.gestor_productos.microservice_gestor_productos.excepciones;

public class CredencialesNoValidas extends RuntimeException {
}