package uma.informatica.sii.gestor_productos.microservice_gestor_productos.controladores;

import org.springframework.web.util.UriComponentsBuilder;

import uma.informatica.sii.gestor_productos.microservice_gestor_productos.dtos.ProductoDTO;
import uma.informatica.sii.gestor_productos.microservice_gestor_productos.servicios.ProductoService;
import uma.informatica.sii.gestor_productos.microservice_gestor_productos.entity.Producto;
import uma.informatica.sii.gestor_productos.microservice_gestor_productos.excepciones.CredencialesNoValidas;
import uma.informatica.sii.gestor_productos.microservice_gestor_productos.excepciones.EntidadNoExistente;
import uma.informatica.sii.gestor_productos.microservice_gestor_productos.excepciones.SinPermisosSuficientes;
import uma.informatica.sii.gestor_productos.microservice_gestor_productos.mappers.ProductoMapper;

import java.net.URI;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;




@RestController
@RequestMapping("/productos")
public class ProductoController {
    private final ProductoService productoService;
    public ProductoController(ProductoService productoService) {
        this.productoService = productoService;
    }

    @GetMapping
    public ResponseEntity<?> getProducto(
            @RequestParam(required = false) Integer idProducto,
            @RequestParam(required = false) String gtin,
            @RequestParam(required = false) Integer idCuenta,
            @RequestParam(required = false) Integer idCategoria,
            @RequestHeader("Authorization") String jwtToken) {

        int count = 0;
        if (idProducto != null) count++;
        if (gtin != null) count++;
        if (idCuenta != null) count++;
        if (idCategoria != null) count++;

        if (count != 1) {
            return ResponseEntity.badRequest().body("Debe proporcionar exactamente un parámetro de consulta.");
        }

        if (idProducto != null) {
            return ResponseEntity.ok(productoService.getProductoPorId(idProducto, jwtToken));
        }

        if (gtin != null) {
            return ResponseEntity.ok(productoService.getProductoPorGtin(gtin, jwtToken));
        }

        if (idCuenta != null) {
            return ResponseEntity.ok(productoService.getProductosPorIdCuenta(idCuenta, jwtToken));
        }

        if (idCategoria != null) {
            return ResponseEntity.ok(productoService.getProductosPorIdCategoria(idCategoria, jwtToken));
        }

        return ResponseEntity.badRequest().build();
    }


    @PostMapping
    public ResponseEntity<ProductoDTO> crearProducto(@RequestBody ProductoDTO productoDTO, UriComponentsBuilder builder) {
        productoDTO.setId(null);
        ProductoDTO producto = ProductoMapper.toDTO(
            productoService.crearProducto(
                ProductoMapper.toEntity(productoDTO), productoDTO.getCuentaId()
            )
        );
        URI uri = builder
                .path(String.format("/%d", productoDTO.getId()))
                .build()
                .toUri();
        return ResponseEntity.created(uri).body(producto);
    }

    @PutMapping("{id}")
    public ResponseEntity<ProductoDTO> modificarProducto(@PathVariable Integer id, @RequestBody ProductoDTO producto) {
        producto.setId(id);
        Producto productoModificado = productoService.modificarProducto(ProductoMapper.toEntity(producto));
        return ResponseEntity.ok(ProductoMapper.toDTO(productoModificado));
    }
    
    @DeleteMapping("/{idProducto}")
    public ResponseEntity<Void> eliminarProducto(@PathVariable Integer idProducto) {
        productoService.eliminarProducto(idProducto);
        return ResponseEntity.noContent().build();
    }

    @ExceptionHandler(EntidadNoExistente.class)
    public ResponseEntity<String> handleEntidadNoExistente(EntidadNoExistente ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
    }

    @ExceptionHandler(SinPermisosSuficientes.class)
    public ResponseEntity<String> handleSinPermisosSuficientes(SinPermisosSuficientes ex) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(ex.getMessage());
    }

    @ExceptionHandler(CredencialesNoValidas.class)
    public ResponseEntity<String> handleCredencialesNoValidas(CredencialesNoValidas ex) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(ex.getMessage());
    }
}
