package uma.informatica.sii.gestor_productos.microservice_gestor_productos.dtos;

import lombok.*;
@Data
@Getter
@Setter
@EqualsAndHashCode
@ToString
public class RelacionDTO {
    private Integer id;
    private String nombre;
    private String descripcion;
}
