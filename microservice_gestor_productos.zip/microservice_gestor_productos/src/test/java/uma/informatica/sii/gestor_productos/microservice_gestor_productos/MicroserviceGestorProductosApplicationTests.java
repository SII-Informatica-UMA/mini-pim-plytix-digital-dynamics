package uma.informatica.sii.gestor_productos.microservice_gestor_productos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceGestorProductosApplicationTests {

	@Test
	void contextLoads() {
	}

}
